<?php 
$koneksi = mysqli_connect("localhost", "root", "", "03088");
